# @lamalibre/portlama-agent

Mac tunnel agent for Portlama — installs a Chisel tunnel client and manages it
as a macOS launchd agent.

## Installation

```bash
npx @lamalibre/portlama-agent setup
```

The setup command downloads the Chisel binary, configures the tunnel connection,
installs a launchd plist, and starts the agent. The panel provides the
connection details and an agent-scoped mTLS certificate.

## Commands

| Command     | Description                              |
| ----------- | ---------------------------------------- |
| `setup`     | Install Chisel and configure the tunnel  |
| `update`    | Update Chisel binary to latest version   |
| `uninstall` | Remove Chisel, plist, and configuration  |
| `status`    | Show tunnel connection status            |
| `logs`      | Display recent tunnel logs               |

## Requirements

| Requirement | Details         |
| ----------- | --------------- |
| OS          | macOS           |
| Node.js     | >= 20.0.0       |
| Access      | User account (no root required) |

## How It Works

The agent registers with the Portlama panel using an agent-scoped mTLS
certificate (not the admin certificate). It connects to the server's Chisel
endpoint over WebSocket-over-HTTPS and exposes local ports as configured
in the panel's tunnel settings.

The launchd plist ensures the tunnel reconnects automatically after reboot
or network changes.

## Further Reading

See the main repository for architecture, tunnel configuration, and the full
development plan: <https://github.com/lamalibre/portlama>

## License

[Polyform Noncommercial 1.0.0](./LICENSE.md) — see [LICENSE.md](./LICENSE.md) for details.
